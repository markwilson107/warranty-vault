type SetupStep = {
    number: number;
    title: string;
    image: any;
}