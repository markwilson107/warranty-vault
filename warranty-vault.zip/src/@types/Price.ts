type Price = {
  title: string;
  desc: string;
  price: string;
  priceFrequency: string;
  varient: string;
  features: string[];
};
