type NavLink = {
    title: string;
    url: string;
    searchParam?: string; 
}