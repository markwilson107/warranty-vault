type Social = {
    title: string;
    url: string;
    icon: any;
}