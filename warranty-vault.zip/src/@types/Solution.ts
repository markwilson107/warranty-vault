type Solution = {
    title: string;
    buttonText: string;
    image: any;
}