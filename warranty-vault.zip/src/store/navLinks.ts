export default [
  { title: "Solution", url: "/", searchParam: "/?scroll=solution" },
  { title: "Pricing", url: "/", searchParam: "/?scroll=pricing" },
  { title: "Contact", url: "/contact" },
] as NavLink[];
